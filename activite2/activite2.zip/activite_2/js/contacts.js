/* 
Activité : gestion des contacts
*/

// TODO : complétez le programme